const { v4: uuidv4 } = require('uuid');
const recipes = [];
const users = [{ id: '1', username: 'john_doe', password: 'password123', email: 'john@example.com' }];
const jwt = require('jsonwebtoken');

const resolvers = {
  Query: {
    getRecipes: () => recipes,
    getRecipe: (_, { id }) => recipes.find(recipe => recipe.id === id),
  },
  Mutation: {
    addRecipe: (_, { title, ingredients, instructions, category, date }) => {
      const newRecipe = { id: uuidv4(), title, ingredients, instructions, category, date, userId: '1' };
      recipes.push(newRecipe);
      return newRecipe;
    },
    editRecipe: (_, { id, title, ingredients, instructions, category, date }) => {
      const recipe = recipes.find(recipe => recipe.id === id);
      if (recipe) {
        if (title) recipe.title = title;
        if (ingredients) recipe.ingredients = ingredients;
        if (instructions) recipe.instructions = instructions;
        if (category) recipe.category = category;
        if (date) recipe.date = date;
        return recipe;
      }
      return null;
    },
    deleteRecipe: (_, { id }) => {
      const recipeIndex = recipes.findIndex(recipe => recipe.id === id);
      if (recipeIndex > -1) {
        recipes.splice(recipeIndex, 1);
        return true;
      }
      return false;
    },
    login: (_, { username, password }) => {
      const user = users.find(user => user.username === username && user.password === password);
      if (user) {
        const token = jwt.sign({ id: user.id }, 'secret', { expiresIn: '1h' });
        return token;
      }
      throw new Error('Invalid credentials');
    },
  },
};

module.exports = resolvers;